#!/system/bin/sh
# Clear precompiled services.jar caches so patched DEX is loaded.
rm -f /data/dalvik-cache/arm64/system@framework@services.jar@classes.dex 2>/dev/null
rm -f /data/dalvik-cache/arm64/system@framework@services.jar@classes.vdex 2>/dev/null
rm -f /data/dalvik-cache/arm/system@framework@services.jar@classes.dex 2>/dev/null
rm -f /data/dalvik-cache/arm/system@framework@services.jar@classes.vdex 2>/dev/null
