#!/system/bin/sh
ui_print "Boox AMS fix for Tab10CPro firmware 4.2.1"
ui_print "Systemless services.jar overlay; reboot to apply."
